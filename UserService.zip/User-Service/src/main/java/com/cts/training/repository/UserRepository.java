package com.cts.training.repository;

 import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.training.bean.User;
import java.util.Optional;
 
public interface UserRepository extends JpaRepository<User, Long> {

	Optional<User> findByAddress(String address);
}
